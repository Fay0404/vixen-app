-- Jalankan di Supabase: SQL Editor > New query > Run
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null,
  username text unique not null,
  fcm_token text,
  updated_at timestamptz default now()
);

alter table public.profiles enable row level security;

create policy "baca profil sendiri" on public.profiles
  for select using (auth.uid() = id);
create policy "buat profil sendiri" on public.profiles
  for insert with check (auth.uid() = id);
create policy "ubah profil sendiri" on public.profiles
  for update using (auth.uid() = id);
