import re, pathlib
m = pathlib.Path("android/app/src/main/AndroidManifest.xml")
x = m.read_text()
perms = """    <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
    <uses-permission android:name="android.permission.QUERY_ALL_PACKAGES"/>
    <uses-permission android:name="android.permission.CAMERA"/>
    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
"""
svc = '''    <service android:name="flutter.overlay.window.flutter_overlay_window.OverlayService" android:exported="false" android:foregroundServiceType="specialUse"/>
'''
if "SYSTEM_ALERT_WINDOW" not in x:
    x = x.replace("<application", perms + "    <application", 1)
    x = x.replace("</application>", svc + "    </application>", 1)
    m.write_text(x)
x = m.read_text()
m.write_text(re.sub(r'android:label="[^"]*"', 'android:label="Vixen"', x, count=1))
for g in ("android/app/build.gradle", "android/app/build.gradle.kts"):
    p = pathlib.Path(g)
    if p.exists():
        t = p.read_text()
        t = re.sub(r"minSdk(Version)?\s*=?\s*flutter\.minSdkVersion", "minSdk = 23" if g.endswith("kts") else "minSdkVersion 23", t)
        p.write_text(t)
print("manifest dan minSdk sudah dipatch")
