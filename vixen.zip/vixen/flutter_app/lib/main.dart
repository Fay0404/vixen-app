import 'package:flutter/material.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import 'commands.dart';
import 'features.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'auth.dart';
import 'config.dart';
import 'push.dart';

const orange = Color(0xFFFF7A2F);
const plum = Color(0xFF140B22);

final theme = ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    colorSchemeSeed: orange,
    scaffoldBackgroundColor: const Color(0xFF0B0612));

final messengerKey = GlobalKey<ScaffoldMessengerState>();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (Config.ready) {
    await Supabase.initialize(url: Config.supabaseUrl, anonKey: Config.supabaseAnonKey);
    await Push.setup();
  }
  runApp(MaterialApp(
      title: 'Vixen',
      debugShowCheckedModeBanner: false,
      theme: theme,
      scaffoldMessengerKey: messengerKey,
      home: Config.ready ? const AuthGate() : const NotConfigured()));
}

// Dijalankan oleh plugin untuk widget yang melayang.
@pragma('vm:entry-point')
void overlayMain() => runApp(MaterialApp(
    debugShowCheckedModeBanner: false, color: Colors.transparent, theme: theme, home: const Bubble()));

const quick = ['Senter', 'Wi-Fi', 'Bluetooth', 'Data', 'Hotspot', 'Pesawat', 'Lokasi', 'NFC', 'Volume', 'Layar', 'Hemat baterai', 'Pengaturan'];

class HomePage extends StatefulWidget {
  final Map<String, dynamic> profile;
  final Future<void> Function() onProfileChanged;
  const HomePage({super.key, required this.profile, required this.onProfileChanged});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final c = TextEditingController();
  String status = '';

  Future<void> start() async {
    if (!await FlutterOverlayWindow.isPermissionGranted()) {
      await FlutterOverlayWindow.requestPermission();
      return;
    }
    await FlutterOverlayWindow.showOverlay(
      height: 640,
      width: 560,
      alignment: OverlayAlignment.centerRight,
      enableDrag: true,
      flag: OverlayFlag.focusPointer,
      overlayTitle: 'Vixen',
      overlayContent: 'Aktif',
    );
  }

  Future<void> run(String text) async {
    final r = await Vixen.run(text);
    if (mounted) setState(() => status = r);
  }

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context).textTheme;
    return Scaffold(
      body: SafeArea(
        child: ListView(padding: const EdgeInsets.all(20), children: [
          Row(children: [
            ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: Image.asset('assets/icon.png', width: 64, height: 64)),
            const SizedBox(width: 14),
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Vixen', style: t.headlineMedium),
              Text('Halo, ${widget.profile['display_name']}'),
            ]),
            const Spacer(),
            PopupMenuButton<String>(
              onSelected: (v) {
                if (v == 'out') {
                  Supabase.instance.client.auth.signOut();
                } else {
                  Navigator.push(context, MaterialPageRoute(builder: (_) =>
                      ProfilePage(initial: widget.profile, onSaved: widget.onProfileChanged)));
                }
              },
              itemBuilder: (_) => const [
                PopupMenuItem(value: 'edit', child: Text('Ubah profil')),
                PopupMenuItem(value: 'out', child: Text('Keluar')),
              ],
            ),
          ]),
          const SizedBox(height: 20),
          FilledButton.icon(
              onPressed: start,
              icon: const Icon(Icons.bubble_chart),
              label: const Text('Aktifkan asisten melayang')),
          TextButton(
              onPressed: FlutterOverlayWindow.closeOverlay,
              child: const Text('Matikan asisten melayang')),
          const SizedBox(height: 8),
          TextField(
              controller: c,
              onSubmitted: run,
              decoration: const InputDecoration(
                  hintText: 'buka wa, senter on, wifi…', border: OutlineInputBorder())),
          const SizedBox(height: 8),
          FilledButton(onPressed: () => run(c.text), child: const Text('GO')),
          const SizedBox(height: 8),
          Text(status),
          const SizedBox(height: 20),
          Text('Akses cepat', style: t.titleMedium),
          const SizedBox(height: 8),
          Wrap(spacing: 8, runSpacing: 8, children: [
            for (final q in quick)
              ActionChip(label: Text(q), onPressed: () => run(q.toLowerCase()))
          ]),
          const SizedBox(height: 28),
          Text('Fungsi lengkap', style: t.titleLarge),
          const SizedBox(height: 4),
          const Text(
              'Android tidak mengizinkan aplikasi menyalakan Wi-Fi, Bluetooth, atau data secara diam-diam. Vixen membuka panelnya, lalu kamu tinggal sekali ketuk. Senter menyala langsung.',
              style: TextStyle(color: Colors.white70)),
          const SizedBox(height: 12),
          for (final f in features)
            Card(
              color: plum,
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(f.title, style: t.titleMedium),
                  const SizedBox(height: 4),
                  Text(f.desc),
                  const SizedBox(height: 6),
                  Text('Contoh: ${f.example}', style: const TextStyle(color: orange)),
                ]),
              ),
            ),
        ]),
      ),
    );
  }
}

class Bubble extends StatefulWidget {
  const Bubble({super.key});
  @override
  State<Bubble> createState() => _BubbleState();
}

class _BubbleState extends State<Bubble> {
  final c = TextEditingController();
  String status = '';

  Future<void> run() async {
    final r = await Vixen.run(c.text);
    setState(() => status = r);
    c.clear();
  }

  @override
  Widget build(BuildContext context) => Material(
        color: Colors.transparent,
        child: Container(
          margin: const EdgeInsets.all(8),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
              color: plum,
              border: Border.all(color: orange, width: 2),
              borderRadius: BorderRadius.circular(24)),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Align(
                alignment: Alignment.topRight,
                child: GestureDetector(
                    onTap: FlutterOverlayWindow.closeOverlay,
                    child: const Text('Tutup',
                        style: TextStyle(color: Color(0xFFFF6B6B), fontSize: 12)))),
            ClipRRect(
                borderRadius: BorderRadius.circular(18),
                child: Image.asset('assets/icon.png', width: 84, height: 84)),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(
                  child: TextField(
                      controller: c,
                      onSubmitted: (_) => run(),
                      style: const TextStyle(color: Colors.white),
                      decoration: const InputDecoration(
                          isDense: true,
                          hintText: 'buka …',
                          hintStyle: TextStyle(color: Colors.white54),
                          border: OutlineInputBorder()))),
              const SizedBox(width: 6),
              FilledButton(onPressed: run, child: const Text('GO')),
            ]),
            const SizedBox(height: 6),
            Text(status, style: const TextStyle(color: Colors.white70, fontSize: 12)),
          ]),
        ),
      );
}
