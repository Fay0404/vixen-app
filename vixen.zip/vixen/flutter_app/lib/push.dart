import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'config.dart';
import 'main.dart' show messengerKey;

class Push {
  static bool _ok = false, _listening = false;

  static Future<void> setup() async {
    if (!Config.firebaseReady) return;
    try {
      await Firebase.initializeApp(
          options: FirebaseOptions(
              apiKey: Config.fbApiKey,
              appId: Config.fbAppId,
              messagingSenderId: Config.fbSenderId,
              projectId: Config.fbProjectId));
      _ok = true;
    } catch (_) {}
  }

  /// Dipanggil setelah login dan profil ada.
  static Future<void> register() async {
    if (!_ok) return;
    try {
      final fm = FirebaseMessaging.instance;
      await fm.requestPermission();
      await fm.subscribeToTopic('all');
      await _save(await fm.getToken());
      if (_listening) return;
      _listening = true;
      fm.onTokenRefresh.listen(_save);
      FirebaseMessaging.onMessage.listen((m) {
        final n = m.notification;
        if (n == null) return;
        messengerKey.currentState?.showSnackBar(
            SnackBar(content: Text('${n.title ?? ''} ${n.body ?? ''}'.trim())));
      });
    } catch (_) {}
  }

  static Future<void> _save(String? token) async {
    final sb = Supabase.instance.client;
    final u = sb.auth.currentUser;
    if (token == null || u == null) return;
    try {
      await sb.from('profiles').update({'fcm_token': token}).eq('id', u.id);
    } catch (_) {}
  }
}
