import 'dart:async';
import 'package:cloudflare_turnstile/cloudflare_turnstile.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'config.dart';
import 'main.dart';
import 'push.dart';

class NotConfigured extends StatelessWidget {
  const NotConfigured({super.key});
  @override
  Widget build(BuildContext context) => const Scaffold(
      body: Center(
          child: Padding(
              padding: EdgeInsets.all(24),
              child: Text('Vixen belum dikonfigurasi. Isi GitHub Secrets (lihat README), lalu build ulang.',
                  textAlign: TextAlign.center))));
}

class AuthGate extends StatefulWidget {
  const AuthGate({super.key});
  @override
  State<AuthGate> createState() => _AuthGateState();
}

class _AuthGateState extends State<AuthGate> {
  final sb = Supabase.instance.client;
  Map<String, dynamic>? profile;
  bool loading = false;
  late final StreamSubscription sub;

  @override
  void initState() {
    super.initState();
    _load();
    sub = sb.auth.onAuthStateChange.listen((_) => _load());
  }

  @override
  void dispose() {
    sub.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    final u = sb.auth.currentUser;
    if (u == null) {
      if (mounted) setState(() { profile = null; loading = false; });
      return;
    }
    if (mounted) setState(() => loading = true);
    try {
      profile = await sb.from('profiles').select().eq('id', u.id).maybeSingle();
    } catch (_) {
      profile = null;
    }
    if (mounted) setState(() => loading = false);
    if (profile != null) Push.register();
  }

  @override
  Widget build(BuildContext context) {
    if (sb.auth.currentUser == null) return const LoginPage();
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (profile == null) return ProfilePage(onSaved: _load);
    return HomePage(profile: profile!, onProfileChanged: _load);
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final email = TextEditingController(), pass = TextEditingController();
  final turnstile = TurnstileController();
  bool signup = false, busy = false;
  String? token, msg;

  Future<void> submit() async {
    if (email.text.trim().isEmpty || pass.text.length < 6) {
      setState(() => msg = 'Isi email dan kata sandi (minimal 6 karakter)');
      return;
    }
    if (token == null) {
      setState(() => msg = 'Selesaikan verifikasi dulu');
      return;
    }
    setState(() { busy = true; msg = null; });
    try {
      final auth = Supabase.instance.client.auth;
      if (signup) {
        final r = await auth.signUp(email: email.text.trim(), password: pass.text, captchaToken: token);
        if (r.session == null) msg = 'Pendaftaran berhasil. Cek email untuk konfirmasi, lalu masuk.';
      } else {
        await auth.signInWithPassword(email: email.text.trim(), password: pass.text, captchaToken: token);
      }
    } on AuthException catch (e) {
      msg = e.message;
    } catch (_) {
      msg = 'Gagal terhubung. Periksa internet.';
    }
    token = null;
    turnstile.refreshToken();
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: ListView(padding: const EdgeInsets.all(24), children: [
            const SizedBox(height: 24),
            Center(
                child: ClipRRect(
                    borderRadius: BorderRadius.circular(24),
                    child: Image.asset('assets/icon.png', width: 96, height: 96))),
            const SizedBox(height: 12),
            Center(child: Text('Vixen', style: Theme.of(context).textTheme.headlineMedium)),
            const SizedBox(height: 24),
            TextField(
                controller: email,
                keyboardType: TextInputType.emailAddress,
                decoration: const InputDecoration(labelText: 'Email', border: OutlineInputBorder())),
            const SizedBox(height: 12),
            TextField(
                controller: pass,
                obscureText: true,
                decoration: const InputDecoration(labelText: 'Kata sandi', border: OutlineInputBorder())),
            const SizedBox(height: 12),
            Center(
                child: CloudflareTurnstile(
                    siteKey: Config.turnstileSiteKey,
                    controller: turnstile,
                    onTokenReceived: (t) => setState(() => token = t),
                    onTokenExpired: () => setState(() => token = null))),
            if (msg != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(msg!)),
            const SizedBox(height: 12),
            FilledButton(
                onPressed: busy ? null : submit,
                child: Text(busy ? 'Memproses…' : (signup ? 'Daftar' : 'Masuk'))),
            TextButton(
                onPressed: () => setState(() { signup = !signup; msg = null; }),
                child: Text(signup ? 'Sudah punya akun? Masuk' : 'Belum punya akun? Daftar')),
          ]),
        ),
      );
}

class ProfilePage extends StatefulWidget {
  final Map<String, dynamic>? initial;
  final Future<void> Function() onSaved;
  const ProfilePage({super.key, this.initial, required this.onSaved});
  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  late final name = TextEditingController(text: widget.initial?['display_name'] ?? '');
  late final user = TextEditingController(text: widget.initial?['username'] ?? '');
  bool busy = false;
  String? msg;

  Future<void> save() async {
    final u = user.text.trim().toLowerCase();
    if (name.text.trim().isEmpty) return setState(() => msg = 'Nama tidak boleh kosong');
    if (!RegExp(r'^[a-z0-9_]{3,20}$').hasMatch(u)) {
      return setState(() => msg = 'Username 3-20 karakter: huruf kecil, angka, atau _');
    }
    setState(() { busy = true; msg = null; });
    final sb = Supabase.instance.client;
    try {
      await sb.from('profiles').upsert({
        'id': sb.auth.currentUser!.id,
        'display_name': name.text.trim(),
        'username': u,
        'updated_at': DateTime.now().toUtc().toIso8601String(),
      });
      await widget.onSaved();
      if (mounted && Navigator.canPop(context)) Navigator.pop(context);
    } on PostgrestException catch (e) {
      msg = e.code == '23505' ? 'Username sudah dipakai' : e.message;
    } catch (_) {
      msg = 'Gagal menyimpan. Periksa internet.';
    }
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(widget.initial == null ? 'Buat profil' : 'Ubah profil')),
        body: ListView(padding: const EdgeInsets.all(24), children: [
          TextField(
              controller: name,
              decoration: const InputDecoration(labelText: 'Nama tampilan', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          TextField(
              controller: user,
              decoration: const InputDecoration(labelText: 'Username', border: OutlineInputBorder())),
          if (msg != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(msg!)),
          const SizedBox(height: 16),
          FilledButton(onPressed: busy ? null : save, child: Text(busy ? 'Menyimpan…' : 'Simpan')),
          if (widget.initial == null)
            TextButton(
                onPressed: () => Supabase.instance.client.auth.signOut(),
                child: const Text('Keluar')),
        ]),
      );
}
