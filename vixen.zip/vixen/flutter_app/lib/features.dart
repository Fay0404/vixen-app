class Feature {
  final String title, desc, example;
  const Feature(this.title, this.desc, this.example);
}

const features = [
  Feature('Buka aplikasi', 'Membuka aplikasi apa pun yang terpasang di HP. Cukup ketik sebagian namanya.', 'buka wa · buka tik · buka kamera'),
  Feature('Senter', 'Menyalakan atau mematikan senter langsung, tanpa membuka pengaturan.', 'senter on · matikan senter'),
  Feature('Wi-Fi', 'Membuka panel Wi-Fi. Tinggal geser sakelarnya.', 'wifi · aktifkan wifi'),
  Feature('Bluetooth', 'Membuka pengaturan Bluetooth untuk menyalakan dan menyambungkan perangkat.', 'bluetooth'),
  Feature('Internet dan data seluler', 'Membuka panel koneksi internet.', 'data · internet'),
  Feature('Hotspot', 'Membuka pengaturan jaringan untuk membagikan internet.', 'hotspot'),
  Feature('Mode pesawat', 'Membuka pengaturan mode pesawat.', 'pesawat'),
  Feature('Lokasi (GPS)', 'Membuka pengaturan lokasi.', 'lokasi · gps'),
  Feature('NFC', 'Membuka pengaturan NFC.', 'nfc'),
  Feature('Volume dan suara', 'Membuka panel volume.', 'volume · suara'),
  Feature('Kecerahan layar', 'Membuka pengaturan layar dan kecerahan.', 'layar · kecerahan'),
  Feature('Hemat baterai', 'Membuka pengaturan penghemat baterai.', 'hemat baterai'),
  Feature('Telepon', 'Membuka aplikasi telepon dengan nomor yang sudah terisi.', 'telepon 08123456789'),
  Feature('Cari di Google', 'Mencari apa saja di browser.', 'cari resep nasi goreng'),
  Feature('Pengaturan', 'Membuka halaman pengaturan utama HP.', 'pengaturan'),
];
