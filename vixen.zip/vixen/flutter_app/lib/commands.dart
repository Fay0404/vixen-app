import 'package:android_intent_plus/android_intent.dart';
import 'package:android_intent_plus/flag.dart';
import 'package:torch_light/torch_light.dart';
import 'launcher.dart';

class _Cmd {
  final List<String> keys;
  final String label;
  final List<String> actions;
  const _Cmd(this.keys, this.label, this.actions);
}

const _cmds = [
  _Cmd(['wifi', 'wi-fi', 'wi fi'], 'Wi-Fi', ['android.settings.panel.action.WIFI', 'android.settings.WIFI_SETTINGS']),
  _Cmd(['bluetooth', 'blutut'], 'Bluetooth', ['android.settings.BLUETOOTH_SETTINGS']),
  _Cmd(['data', 'internet', 'kuota'], 'Internet', ['android.settings.panel.action.INTERNET_CONNECTIVITY', 'android.settings.DATA_ROAMING_SETTINGS']),
  _Cmd(['hotspot', 'tethering'], 'Hotspot', ['android.settings.WIRELESS_SETTINGS']),
  _Cmd(['pesawat'], 'Mode pesawat', ['android.settings.AIRPLANE_MODE_SETTINGS']),
  _Cmd(['lokasi', 'gps'], 'Lokasi', ['android.settings.LOCATION_SOURCE_SETTINGS']),
  _Cmd(['nfc'], 'NFC', ['android.settings.panel.action.NFC', 'android.settings.NFC_SETTINGS']),
  _Cmd(['volume', 'suara'], 'Volume', ['android.settings.panel.action.VOLUME', 'android.settings.SOUND_SETTINGS']),
  _Cmd(['layar', 'kecerahan', 'brightness'], 'Layar', ['android.settings.DISPLAY_SETTINGS']),
  _Cmd(['hemat baterai', 'baterai'], 'Hemat baterai', ['android.settings.BATTERY_SAVER_SETTINGS']),
  _Cmd(['pengaturan', 'setelan', 'settings'], 'Pengaturan', ['android.settings.SETTINGS']),
];

class Vixen {
  static bool _torchOn = false;

  static Future<String> run(String input) async {
    final q = input.toLowerCase().trim();
    if (q.isEmpty) return 'Ketik perintah dulu';

    var m = RegExp(r'^(telepon|telpon|call|hubungi)\s+([\d+\s-]+)$').firstMatch(q);
    if (m != null) {
      final n = m.group(2)!.replaceAll(RegExp(r'[\s-]'), '');
      final ok = await _launch(['android.intent.action.DIAL'], data: 'tel:$n');
      return ok ? 'Membuka telepon ke $n' : 'Gagal membuka telepon';
    }
    m = RegExp(r'^(cari|search|google)\s+(.+)$').firstMatch(q);
    if (m != null) {
      final url = 'https://www.google.com/search?q=${Uri.encodeQueryComponent(m.group(2)!)}';
      final ok = await _launch(['android.intent.action.VIEW'], data: url);
      return ok ? 'Mencari ${m.group(2)}' : 'Gagal membuka browser';
    }

    final padded = ' $q ';
    if (['senter', 'flash', 'lampu'].any((k) => padded.contains(' $k '))) {
      return _torch(q);
    }
    for (final c in _cmds) {
      if (c.keys.any((k) => padded.contains(' $k '))) {
        final ok = await _launch(c.actions);
        return ok ? 'Membuka ${c.label}' : 'Gagal membuka ${c.label}';
      }
    }
    final n = await AppLauncher.open(q);
    return n == null ? 'Perintah tidak dikenali' : 'Membuka $n';
  }

  static Future<String> _torch(String q) async {
    final off = RegExp(r'\b(mati|matikan|off|tutup)\b').hasMatch(q);
    final on = RegExp(r'\b(on|nyala|nyalakan|hidup|hidupkan|aktifkan|aktif)\b').hasMatch(q);
    final want = off ? false : (on ? true : !_torchOn);
    try {
      if (want) {
        await TorchLight.enableTorch();
      } else {
        await TorchLight.disableTorch();
      }
      _torchOn = want;
      return want ? 'Senter menyala' : 'Senter mati';
    } catch (_) {
      return 'Senter tidak tersedia';
    }
  }

  static Future<bool> _launch(List<String> actions, {String? data}) async {
    for (final a in actions) {
      try {
        await AndroidIntent(action: a, data: data, flags: const [Flag.FLAG_ACTIVITY_NEW_TASK]).launch();
        return true;
      } catch (_) {}
    }
    return false;
  }
}
