import 'package:installed_apps/installed_apps.dart';

class AppLauncher {
  static List<dynamic>? _cache;
  static const aliases = {
    'wa': 'whatsapp', 'ig': 'instagram', 'yt': 'youtube', 'fb': 'facebook',
    'tele': 'telegram', 'tt': 'tiktok', 'tik tok': 'tiktok', 'tokped': 'tokopedia',
    'gmaps': 'maps', 'peta': 'maps', 'playstore': 'play store', 'twitter': 'x',
  };

  static Future<List<dynamic>> _apps() async =>
      _cache ??= await InstalledApps.getInstalledApps(false, false);

  /// Mengembalikan nama aplikasi yang dibuka, atau null jika tidak ketemu.
  static Future<String?> open(String input) async {
    var q = input.toLowerCase().trim().replaceFirst(
        RegExp(r'^(tolong\s+)?(buka|open|jalankan|bukain)\s+'), '');
    if (q.isEmpty) return null;
    q = aliases[q] ?? q;
    dynamic best;
    var bestScore = 0;
    for (final a in await _apps()) {
      final name = '${a.name}'.toLowerCase();
      var s = 0;
      if (name == q) {
        s = 3;
      } else if (name.startsWith(q)) {
        s = 2;
      } else if (name.contains(q)) {
        s = 1;
      }
      if (s > bestScore ||
          (s == bestScore && s > 0 && name.length < '${best.name}'.length)) {
        best = a;
        bestScore = s;
      }
    }
    if (best == null) return null;
    await InstalledApps.startApp('${best.packageName}');
    return '${best.name}';
  }
}
