// Nilai diisi lewat --dart-define (dari GitHub Secrets), jadi tidak ada kunci di kode.
class Config {
  static const supabaseUrl = String.fromEnvironment('SUPABASE_URL');
  static const supabaseAnonKey = String.fromEnvironment('SUPABASE_ANON_KEY');
  static const turnstileSiteKey = String.fromEnvironment('TURNSTILE_SITE_KEY');
  static const fbApiKey = String.fromEnvironment('FIREBASE_API_KEY');
  static const fbAppId = String.fromEnvironment('FIREBASE_APP_ID');
  static const fbSenderId = String.fromEnvironment('FIREBASE_SENDER_ID');
  static const fbProjectId = String.fromEnvironment('FIREBASE_PROJECT_ID');

  static bool get ready =>
      supabaseUrl.isNotEmpty && supabaseAnonKey.isNotEmpty && turnstileSiteKey.isNotEmpty;
  static bool get firebaseReady =>
      fbApiKey.isNotEmpty && fbAppId.isNotEmpty && fbSenderId.isNotEmpty && fbProjectId.isNotEmpty;
}
