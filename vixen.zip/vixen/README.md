# Vixen

Ketik perintah, HP langsung jalan: "buka wa", "senter on", "wifi", "cari resep".

- `web/` : versi web (statis), deploy ke EdgeOne Pages (output directory: `web`)
- `flutter_app/` : aplikasi Android Vixen dengan widget melayang dan ikon rubah
- `.github/workflows/build-apk.yml` : build APK otomatis di GitHub (Actions > Build APK > Artifacts > vixen-apk)

## Fungsi
Buka aplikasi, senter, Wi-Fi, Bluetooth, internet/data, hotspot, mode pesawat, lokasi, NFC, volume, layar, hemat baterai, telepon, cari di Google, pengaturan.
Daftar lengkap dengan contoh ada di halaman utama aplikasi.

Catatan: Android tidak mengizinkan aplikasi menyalakan Wi-Fi, Bluetooth, atau data secara diam-diam. Vixen membuka panelnya, tinggal sekali ketuk. Senter menyala langsung.

## Login, anti-bot, dan notifikasi
Alur: layar login (Supabase + Cloudflare Turnstile) > buat profil > halaman utama. Token notifikasi disimpan di tabel `profiles`.

### 1. Supabase
1. Buat project di supabase.com.
2. SQL Editor > jalankan isi `supabase/schema.sql`.
3. Project Settings > API: salin **Project URL** dan **anon public key**.
4. Authentication > Providers: pastikan Email aktif (matikan "Confirm email" kalau mau langsung masuk).

### 2. Cloudflare Turnstile
1. Dashboard Cloudflare > Turnstile > Add widget (mode Managed). Tambahkan hostname `localhost`.
2. Salin **Site key** (untuk aplikasi) dan **Secret key**.
3. Supabase > Authentication > Attack Protection (Bot and Abuse Protection) > aktifkan CAPTCHA, pilih Turnstile, tempel **Secret key**.

### 3. Firebase (push)
1. console.firebase.google.com > buat project > Add app > Android, package name `com.asisten.asisten_hp`.
2. Unduh `google-services.json` (hanya untuk disalin nilainya, tidak perlu dimasukkan ke repo):
   - FIREBASE_API_KEY = `client[0].api_key[0].current_key`
   - FIREBASE_APP_ID = `client[0].client_info.mobilesdk_app_id`
   - FIREBASE_SENDER_ID = `project_info.project_number`
   - FIREBASE_PROJECT_ID = `project_info.project_id`

### 4. GitHub Secrets
Repo > Settings > Secrets and variables > Actions > New repository secret. Buat 7 secret:
`SUPABASE_URL`, `SUPABASE_ANON_KEY`, `TURNSTILE_SITE_KEY`, `FIREBASE_API_KEY`, `FIREBASE_APP_ID`, `FIREBASE_SENDER_ID`, `FIREBASE_PROJECT_ID`.
Lalu jalankan Actions > Build APK.

### Kirim push
Firebase Console > Engage > Messaging > New campaign > Notifications. Target: aplikasi Vixen, atau topic `all`.
